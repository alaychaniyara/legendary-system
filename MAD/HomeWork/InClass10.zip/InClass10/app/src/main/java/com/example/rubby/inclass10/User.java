package com.example.rubby.inclass10;

/**
 * Created by Rubby on 4/4/2018.
 */

public class User {
    String iat, exp, jti, user;

    public String getIat() {
        return iat;
    }

    public String getExp() {
        return exp;
    }

    public String getJti() {
        return jti;
    }

    public String getUser() {
        return user;
    }
}
