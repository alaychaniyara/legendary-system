package com.example.rubby.inclass10;

/**
 * Created by Rubby on 4/2/2018.
 */

public class TokenResponse {

    String status, token, user_id, user_email, user_fname, user_lname, user_role;

    public String getStatus() {
        return status;
    }

    public String getToken() {
        return token;
    }

    public String getUser_id() {
        return user_id;
    }

    public String getUser_email() {
        return user_email;
    }

    public String getUser_fname() {
        return user_fname;
    }

    public String getUser_lname() {
        return user_lname;
    }

    public String getUser_role() {
        return user_role;
    }
}
