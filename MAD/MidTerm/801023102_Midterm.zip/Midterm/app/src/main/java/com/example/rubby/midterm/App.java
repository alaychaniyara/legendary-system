package com.example.rubby.midterm;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Rubby on 3/12/2018.
 */

public class App implements Serializable {
    String name,artistName,releaseDate, artworkUrl100, copyright;
    ArrayList<String> genres;

    @Override
    public String toString() {
        return "App{" +
                "name='" + name + '\'' +
                ", artistName='" + artistName + '\'' +
                ", genres='" + genres + '\'' +
                ", releaseDate='" + releaseDate + '\'' +
                ", artworkUrl100='" + artworkUrl100 + '\'' +
                '}';
    }
}
