package com.example.rubby.midterm;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class MainActivity extends AppCompatActivity implements AsyncGetData.IData{

    ArrayList<App> my_apps, filtered_apps;
    ArrayList<String> all_genres;
    ProgressDialog progressDialog;
    Button filter;
    TextView selected_genre;
    AlertDialog.Builder alertDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        progressDialog = new ProgressDialog(this);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Apps");
        selected_genre = findViewById(R.id.textViewFilter);
        filter = findViewById(R.id.buttonFilter);
        alertDialog = new AlertDialog.Builder(this);
        all_genres = new ArrayList();

        if(isConnected()){

            progressDialog.setCancelable(false);

            progressDialog.setTitle("Loading Apps");
            progressDialog.show();
            new AsyncGetData(this).execute("https://rss.itunes.apple.com/api/v1/us/ios-apps/top-grossing/all/50/explicit.json");

            filter.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    alertDialog.show();
                    CharSequence[] temp = all_genres.toArray(new CharSequence[all_genres.size()]);
                    Log.d("test", temp[0].toString());
                }
            });
        }else {
          Toast.makeText(this, "No Internet Please Check Connection", Toast.LENGTH_LONG).show();
        }

    }

    private boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();

        if (networkInfo == null || !networkInfo.isConnected()
                ||(networkInfo.getType()!= connectivityManager.TYPE_WIFI&&
                networkInfo.getType()!=connectivityManager.TYPE_MOBILE)) {
            return false;
        }
        return true;
    }

    @Override
    public void handleData(ArrayList<App> apps) {
        progressDialog.dismiss();

        if(apps.size()==0)
        {
            Toast.makeText(this, "No Apps Found", Toast.LENGTH_SHORT).show();
        }
        else {
            my_apps = apps;
            Collections.sort(my_apps, new Comparator<App>() {
                @Override
                public int compare(App o1, App o2) {
                    return o1.genres.get(0).compareTo(o2.genres.get(0));
                }
            });
            all_genres.add("All");
            for(int i = 0; i < apps.size(); i++){
                for(int j = 0; j < apps.get(i).genres.size(); j++) {
                    if (!(all_genres.contains(apps.get(i).genres.get(j)))){
                        all_genres.add(apps.get(i).genres.get(j));
                        Log.d("test", apps.get(i).genres.get(j));
                    }
                }
            }
            alertDialog.setTitle("Select Genre").setItems(all_genres.toArray(new String[all_genres.size()]), new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    if(all_genres.get(which).equals("All")){
                        ListView displayApps = findViewById(R.id.listViewDisplayApps);
                        AppAdapter appAdapter = new AppAdapter(MainActivity.this, R.layout.display_app, my_apps);
                        displayApps.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                                intent.putExtra("app", my_apps.get(position));
                                startActivity(intent);

                            }
                        });
                        displayApps.setAdapter(appAdapter);
                    }
                    else{
                        filtered_apps = new ArrayList<>();
                        for(int i = 0; i < my_apps.size(); i++){
                            if(my_apps.get(i).genres.contains(all_genres.get(which))){
                                filtered_apps.add(my_apps.get(i));
                            }
                        }
                        ListView displayApps = findViewById(R.id.listViewDisplayApps);
                        AppAdapter appAdapter = new AppAdapter(MainActivity.this, R.layout.display_app, filtered_apps);
                        displayApps.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                            @Override
                            public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                                Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                                intent.putExtra("app", filtered_apps.get(position));
                                startActivity(intent);

                            }
                        });
                        displayApps.setAdapter(appAdapter);
                    }
                    selected_genre.setText(all_genres.get(which));
                }
            });
            ListView displayApps = findViewById(R.id.listViewDisplayApps);
            AppAdapter appAdapter = new AppAdapter(this, R.layout.display_app, apps);
            displayApps.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    Intent intent = new Intent(MainActivity.this, DetailsActivity.class);
                    intent.putExtra("app", my_apps.get(position));
                    startActivity(intent);

                }
            });
            displayApps.setAdapter(appAdapter);
            Log.d("demo", apps.toString());
        }
    }
}
