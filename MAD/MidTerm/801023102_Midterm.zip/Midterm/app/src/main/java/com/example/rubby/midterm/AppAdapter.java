package com.example.rubby.midterm;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.List;

/**
 * Created by Rubby on 3/12/2018.
 */

public class AppAdapter extends ArrayAdapter<App> {
    public AppAdapter(@NonNull Context context, int resource, @NonNull List<App> objects) {
        super(context, resource, objects);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        ViewHolder viewHolder;
        App app=getItem(position);
        if (convertView==null)
        {
            convertView= LayoutInflater.from(getContext()).inflate(R.layout.display_app,parent,false);
            viewHolder=new ViewHolder();
            viewHolder.textViewName= convertView.findViewById(R.id.textViewAppName);
            viewHolder.textViewArtistName= convertView.findViewById(R.id.textViewAppArtistName);
            viewHolder.textViewReleaseDate= convertView.findViewById(R.id.textViewAppReleaseDate);
            viewHolder.textViewGenres= convertView.findViewById(R.id.textViewAppGenres);
            viewHolder.imageViewArtworkUrl100= convertView.findViewById(R.id.imageViewAppImage);
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder= (ViewHolder) convertView.getTag();
        }
        //    viewHolder.textViewTitle.setText(article.title);
        //  viewHolder.textViewPublishedAt.setText(article.publishedat);
        // Picasso.with(getContext()).load(article.urltoimage).into(viewHolder.ImageViewArticle);

        if (app.name.isEmpty()||app.name==null)
        {
            viewHolder.textViewName.setText("No Name");
        }
        else
        {
            viewHolder.textViewName.setText(app.name);
        }
        if (app.artistName.isEmpty()||app.artistName==null)
        {
            viewHolder.textViewArtistName.setText("No Artist Name");
        }
        else
        {
            viewHolder.textViewArtistName.setText(app.artistName);
        }
        if (app.releaseDate.isEmpty()||app.releaseDate==null)
        {
            viewHolder.textViewReleaseDate.setText("No Release Date");
        }
        else
        {
            viewHolder.textViewReleaseDate.setText(app.releaseDate);
        }
        if (app.genres.size() == 0||app.genres==null)
        {
            viewHolder.textViewGenres.setText("No Genres");
        }
        else
        {
            viewHolder.textViewGenres.setText(app.genres.toString());
        }
        if (app.artworkUrl100.isEmpty()||app.artworkUrl100.equals("null")||app.artworkUrl100==null)
        {
            Picasso.with(getContext()).load(R.drawable.ic_launcher_background).into(viewHolder.imageViewArtworkUrl100);
        }
        else
        {
            Picasso.with(getContext()).load(app.artworkUrl100).into(viewHolder.imageViewArtworkUrl100);

        }

        return convertView;
    }

    private static class ViewHolder
    {
        TextView textViewName, textViewReleaseDate, textViewArtistName, textViewGenres;
        ImageView imageViewArtworkUrl100;

    }
}
