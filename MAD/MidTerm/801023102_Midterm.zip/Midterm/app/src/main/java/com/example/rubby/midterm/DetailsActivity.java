package com.example.rubby.midterm;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailsActivity extends AppCompatActivity {

    TextView name, releaseDate, artistName, genres, copyright;
    ImageView image;
    TextView description;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        this.setTitle("App Details");
        name = findViewById(R.id.textViewName);
        releaseDate = findViewById(R.id.textViewReleaseDate);
        artistName = findViewById(R.id.textViewArtistName);
        genres = findViewById(R.id.textViewGenres);
        copyright = findViewById(R.id.textViewCopyright);

        image = findViewById(R.id.selectedImage);

        App app = (App) getIntent().getExtras().getSerializable("app");

        if (app.name.isEmpty()||app.name==null)
        {
            name.setText("No Name");
        }
        else
        {
            name.setText(app.name);
        }
        if (app.releaseDate.isEmpty()||app.releaseDate==null)
        {
            releaseDate.setText("No Release Date");
        }
        else
        {
            releaseDate.setText(app.releaseDate);
        }
        if (app.genres.size() == 0||app.genres==null)
        {
            genres.setText("No Genres");
        }
        else
        {
            genres.setText(app.genres.toString());
        }
        if (app.artistName.isEmpty()||app.artistName==null)
        {
            artistName.setText("No Artist Name");
        }
        else
        {
            artistName.setText(app.artistName);
        }
        if (app.copyright.isEmpty()||app.copyright==null)
        {
            copyright.setText("No Copyright");
        }
        else
        {
            copyright.setText(app.copyright);
        }

        if (app.artworkUrl100.isEmpty()||app.artworkUrl100.equals("null")||app.artworkUrl100==null)
        {
            image.setImageDrawable(getDrawable(R.drawable.ic_launcher_background));
        }
        else
        {
            Picasso.with(this).load(app.artworkUrl100).into(image);
        }
    }
}
